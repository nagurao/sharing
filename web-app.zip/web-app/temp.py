import pandas as pd

# Create a mapping DataFrame
mapping_data = {
    'merchant_cat': ['Shopping Net', 'Grocery Net', 'Misc Net'],
    'model_value': ['shopping_net_model_value', 'grocery_net_model_value', 'misc_net_model_value']
}

mapping_df = pd.DataFrame(mapping_data)

# Function to map dropdown values to model values
def map_dropdown_to_model(selected_value):
    default_value = 'shopping_net_model_value'  # Default value if not found
    model_value = mapping_df[mapping_df['merchant_cat'] == selected_value]['model_value'].values
    return model_value[0] if len(model_value) > 0 else default_value

# Modify the 'predict' route
@app.route('/predict', methods=['POST'])
def predict():
    try:
        cc_num = request.form['cc_num']
        tran_amount = float(request.form['tran_amount'])
        tran_date = request.form['tran_date']
        tran_time = request.form['tran_time']
        merchant_cat = request.form['merchant_cat']

        # Map the dropdown value to the model value using the function
        mapped_merchant_cat = map_dropdown_to_model(merchant_cat)

        # Create a DataFrame with the user input
        input_data = pd.DataFrame({
            'cc_num': [cc_num],
            'tran_amount': [tran_amount],
            'tran_date': [tran_date],
            'tran_time': [tran_time],
            'merchant_cat': [mapped_merchant_cat]
        })

        # Call your ML model function to get the prediction
        prediction = predict_fraud(input_data)
        return render_template('index.html', prediction_text=f'Prediction: {prediction}')
    except Exception as e:
        return render_template('index.html', prediction_text=f'Error: {str(e)}')
