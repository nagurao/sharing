import numpy as np
import pandas as pd
from flask import Flask, request, render_template
import pickle
from icecream import ic
import joblib
import os
import random

pd.options.display.max_columns = None
app = Flask(__name__)

#model = pickle.load(open("./ufo-model.pkl", "rb"))
#with open('../category_encoder.pkl', 'rb') as file:
#    category_encoder = pickle.load(file)

category_encoder_file = '../category_app_encoder.pkl'
trans_hr_encoder_file = '../trans_hr_app_encoder.pkl'
time_period_encoder_file = '../time_period_app_encoder.pkl'
customer_profile_file  = '../customer_profile.pkl'
customer_usage_file = '../customer_usage.pkl'

woe_category_encoder = joblib.load('../woe_category_encoder.pkl')

#woe_encoder = joblib.load('../woe_encoder.pkl')

def load_and_transform_unseen_data(df, col_name, encoder_filename):
    label_encoder, one_hot_encoder = joblib.load(encoder_filename)
    encoded_col = label_encoder.transform(df[col_name])
    encoded_col = encoded_col.reshape(-1, 1)
    one_hot_encoded = one_hot_encoder.transform(encoded_col).astype(int)
    one_hot_df = pd.DataFrame(one_hot_encoded, columns=[f'{col_name}_{cls}' for cls in label_encoder.classes_])
    return one_hot_df

mapping_data = {
    'merchant_cat': ['Shopping POS', 'Grocery POS', 'Misc POS','Shopping Net','Grocery Net','Misc Net','Gas Transport','Home','Kids Pets','Personal Care','Food Dining','Entertainment','Health Fitness','Travel'],
    'model_value': ['shopping_pos', 'grocery_pos', 'misc_pos','shopping_net','grocery_net','misc_net','gas_transport','home','kids_pets','personal_care','food_dining','entertainment','health_fitness','travel']
}

mapping_df = pd.DataFrame(mapping_data)

if os.path.exists(customer_profile_file):
    # Load the DataFrame from the pickle file
    customer_df = pd.read_pickle(customer_profile_file)
else:
    customer_df = pd.DataFrame(columns=['cc_num','category','purchase_power_amt','median_trans_amt','category_woe','state_woe'])
    customer_df.to_pickle(customer_profile_file)

if os.path.exists(customer_usage_file):
    # Load the DataFrame from the pickle file
    customer_usage_df = pd.read_pickle(customer_usage_file)
else:
    customer_usage_df = pd.DataFrame(columns=['cc_num','daily_limit','usage','remaining_amt','median_trans_amt','category_woe','state_woe'])
    customer_df.to_pickle(customer_usage_file)

def map_dropdown_to_model(selected_value):
    default_value = 'shopping_net'  # Default value if not found
    model_value = mapping_df[mapping_df['merchant_cat'] == selected_value]['model_value'].values
    return model_value[0] if len(model_value) > 0 else default_value


def predict_fraud(input_data):
    global customer_df
    try:
        # Perform any necessary data preprocessing on 'input_data' (e.g., date parsing)

        input_data['trans_time'] = pd.to_datetime(input_data['trans_time'], format='%H:%M:%S')
        input_data['trans_hr']   = input_data['trans_time'].dt.hour
        trans_hr_df = load_and_transform_unseen_data(input_data, 'trans_hr', trans_hr_encoder_file)
        input_data = pd.concat([input_data,trans_hr_df],axis=1)
        
        input_data['time_period'] = pd.cut(input_data['trans_hr'], bins=[0, 6, 12, 18, 22, 24], 
                                            labels=['Night', 'Morning', 'Afternoon', 'Evening', 'Night'], right=False, ordered=False)
        time_period_df = load_and_transform_unseen_data(input_data, 'time_period', time_period_encoder_file)
        input_data = pd.concat([input_data,time_period_df],axis=1)

        cat_df = load_and_transform_unseen_data(input_data, 'category', category_encoder_file)
        input_data = pd.concat([input_data,cat_df],axis=1)

        #input_woe_category = woe_category_encoder.transform(input_data)
        #input['category_woe'] = input_woe_category['category']

        ic(input_data)
        cc_num = input_data['cc_num'].iloc[0]
        amt = input_data['amt'].iloc[0]
        
        mask = customer_df['cc_num'] == cc_num
        if mask.any():
            ic("records exists")
        else:
            ic("record not found")
            random_index = random.randint(0, len(customer_df) - 1)
            random_row = customer_df.iloc[random_index]
            random_state_woe = random_row['state_woe']
            for category in mapping_df['model_value']:
                category_df = customer_df[customer_df['category'] == category]
                random_row = category_df.sample(n=1)
                random_category_woe = random_row['category_woe'].values[0]
                if (input_data['category'] == category).any():
                    new_row = {'cc_num': cc_num, 'category': category, 'purchase_power_amt': amt, 'median_trans_amt': amt,'category_woe': random_category_woe,'state_woe':random_state_woe}
                else:
                    new_row = {'cc_num': cc_num, 'category': category, 'purchase_power_amt': 0, 'median_trans_amt': 0,'category_woe': random_category_woe,'state_woe':random_state_woe}
                new_row_df = pd.DataFrame([new_row])
                ic(new_row_df)
                customer_df = pd.concat([customer_df, new_row_df], ignore_index=True)
                customer_df.to_pickle(customer_profile_file)
                customer_df = pd.read_pickle(customer_profile_file)

        input_data.drop(columns=['category','time_period'],axis=1,inplace=True)

        # Use your trained machine learning model to make predictions
        # Replace 'model' with your actual trained model
        #prediction = model.predict(input_data)
        prediction = 1
        # Format the prediction result
        if prediction == 1:
            return 'Flagged as Fraud'
        else:
            return 'Not Flagged as Fraud'
    except Exception as e:
        # Handle any errors or exceptions gracefully
        return f'Error: {str(e)}'


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    global customer_df
    try:
        cc_num = request.form['cc_num']
        amt = float(request.form['tran_amount'])
        trans_date = request.form['tran_date']
        trans_time = request.form['tran_time']
        category = map_dropdown_to_model(request.form['merchant_cat'])
        trans_date_time = pd.to_datetime(trans_date + ' ' + trans_time)
        
        # Create a DataFrame with the user input
        input_data = pd.DataFrame({'cc_num': [cc_num],
                                   'amt': [amt],
                                   'trans_date': [trans_date],
                                   'trans_time': [trans_time],
                                   'category': [category],
                                   'trans_date_time': [trans_date_time]})

        
        input_data['trans_time'] = pd.to_datetime(input_data['trans_time']).dt.time
        input_data['trans_date'] = pd.to_datetime(input_data['trans_date'])
        
        ic(cc_num)
        ic(amt)
        ic(trans_date)
        ic(trans_time)
        ic(category)
        ic(trans_date_time)
        
        ic(input_data)


        # Call your ML model function to get the prediction
        prediction = predict_fraud(input_data)
        return render_template('index.html', prediction_text=f'Prediction: {prediction}')
    except Exception as e:
        return render_template('index.html', prediction_text=f'Error: {str(e)}')

if __name__ == "__main__":
    app.run(debug=True)