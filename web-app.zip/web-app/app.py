import numpy as np
import pandas as pd
from flask import Flask, request, render_template
import pickle
from icecream import ic

app = Flask(__name__)

#model = pickle.load(open("./ufo-model.pkl", "rb"))

mapping_data = {
    'merchant_cat': ['Shopping POS', 'Grocery POS', 'Misc POS','Shopping Net','Grocery Net','Misc Net','Gas Transport','Home','Kids Pets','Personal Care','Food Dining','Entertainment','Health Fitness','Travel'],
    'model_value': ['shopping_pos', 'grocery_pos', 'misc_pos','shopping_net','grocery_net','misc_net','gas_transport','home','kids_pets','personal_care','food_dining','entertainment','health_fitness','travel']
}

mapping_df = pd.DataFrame(mapping_data)


def map_dropdown_to_model(selected_value):
    default_value = 'shopping_net'  # Default value if not found
    model_value = mapping_df[mapping_df['merchant_cat'] == selected_value]['model_value'].values
    return model_value[0] if len(model_value) > 0 else default_value


def predict_fraud(input_data):
    try:
        # Perform any necessary data preprocessing on 'input_data' (e.g., date parsing)

        # Use your trained machine learning model to make predictions
        # Replace 'model' with your actual trained model
        #prediction = model.predict(input_data)
        prediction = 1
        # Format the prediction result
        if prediction == 1:
            return 'Flagged as Fraud'
        else:
            return 'Not Flagged as Fraud'
    except Exception as e:
        # Handle any errors or exceptions gracefully
        return f'Error: {str(e)}'


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    try:
        cc_num = request.form['cc_num']
        tran_amount = float(request.form['tran_amount'])
        tran_date = request.form['tran_date']
        tran_time = request.form['tran_time']
        merchant_cat = map_dropdown_to_model(request.form['merchant_cat'])
        # Create a DataFrame with the user input
        input_data = pd.DataFrame({'cc_num': [cc_num],
                                   'tran_amount': [tran_amount],
                                   'tran_date': [tran_date],
                                   'tran_time': [tran_time],
                                   'category': [merchant_cat]})

        ic(cc_num)
        ic(tran_amount)
        ic(tran_date)
        ic(tran_time)
        ic(merchant_cat)
        # Call your ML model function to get the prediction
        prediction = predict_fraud(input_data)
        return render_template('index.html', prediction_text=f'Prediction: {prediction}')
    except Exception as e:
        return render_template('index.html', prediction_text=f'Error: {str(e)}')

if __name__ == "__main__":
    app.run(debug=True)